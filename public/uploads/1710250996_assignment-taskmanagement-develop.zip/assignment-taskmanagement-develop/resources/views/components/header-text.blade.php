<section class="container my-5">
    <div class="card mb-3">
        <div class="card-body">
            <h1 class="card-title">Welcome to Taskify: Your Ultimate Task Management Solution</h5>
            <p class="card-text ">Streamline your productivity, organize your day, and conquer your goals with Taskify – the ultimate task management platform designed to simplify your life.</p>
        </div>
    </div>
</section>
